package com.rubimod.init;

import com.rubimod.blocks.BlockRubyBlock;
import com.rubimod.blocks.BlockRubyOre;
import net.minecraft.block.Block;

public class ModBlocks {
    public static final Block RUBY_ORE = new BlockRubyOre();
    public static final Block RUBY_BLOCK = new BlockRubyBlock();
}
