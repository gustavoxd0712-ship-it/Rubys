package com.rubimod.init;

import com.rubimod.RubiMod;
import net.minecraft.item.Item;

public class ModItems {
    public static final Item RUBY = new Item()
            .setRegistryName(RubiMod.MODID, "ruby")
            .setUnlocalizedName(RubiMod.MODID + ".ruby")
            .setCreativeTab(RubiMod.TAB);
}
