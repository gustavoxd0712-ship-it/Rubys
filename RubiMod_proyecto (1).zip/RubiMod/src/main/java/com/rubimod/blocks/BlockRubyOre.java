package com.rubimod.blocks;

import com.rubimod.RubiMod;
import com.rubimod.init.ModItems;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/** Mena de rubi: requiere pico de diamante (nivel 3) o superior. */
public class BlockRubyOre extends Block {

    public BlockRubyOre() {
        super(Material.ROCK);
        setRegistryName(RubiMod.MODID, "ruby_ore");
        setUnlocalizedName(RubiMod.MODID + ".ruby_ore");
        setCreativeTab(RubiMod.TAB);
        setSoundType(SoundType.STONE);
        setHardness(3.0F);
        setResistance(5.0F);
        setHarvestLevel("pickaxe", 3); // 3 = diamante
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModItems.RUBY;
    }

    @Override
    public int quantityDropped(Random random) {
        return 1;
    }

    @Override
    public int quantityDroppedWithBonus(int fortune, Random random) {
        if (fortune > 0) {
            int bonus = random.nextInt(fortune + 2) - 1;
            if (bonus < 0) {
                bonus = 0;
            }
            return quantityDropped(random) * (bonus + 1);
        }
        return quantityDropped(random);
    }

    @Override
    public int getExpDrop(IBlockState state, IBlockAccess world, BlockPos pos, int fortune) {
        Random rand = world instanceof World ? ((World) world).rand : new Random();
        return MathHelper.getInt(rand, 3, 7);
    }
}
